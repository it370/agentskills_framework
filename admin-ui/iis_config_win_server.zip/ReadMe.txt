Two batch files:

-- setup iis batch file will enable iss windows features, installs url rewrite and arr, setup reverse proxy to port 3000.
After this we should be able to see localhost on IIS pointing localhost:3000

-- Then setup SSL certs for SSL
This creates self signed cert, configures web config for https


-- finally made manual changes in web.config for /api and ws port proxy rules








Working config:


<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <rewrite>
            <rules>
                <clear />
                <rule name="Redirect to HTTPS" stopProcessing="true">
                    <match url="(.*)" />
                    <conditions>
                        <add input="{HTTPS}" pattern="^OFF$" />
                    </conditions>
                    <action type="Redirect" url="https://{HTTP_HOST}/{R:1}" redirectType="SeeOther" />
                </rule>
                <rule name="Proxy API" stopProcessing="true">
  <match url="^api/(.*)" />
  <action type="Rewrite" url="http://localhost:8000/{R:1}" />
</rule>
<rule name="Proxy WebSocket" stopProcessing="true">
  <match url="^ws/(.*)" />
  <action type="Rewrite" url="http://localhost:8000/ws/{R:1}" />
  <serverVariables>
    <set name="HTTP_SEC_WEBSOCKET_EXTENSIONS" value="" />
  </serverVariables>
</rule>
                <rule name="ReverseProxyInboundRule1" stopProcessing="true">
                    <match url="(.*)" />
                    <action type="Rewrite" url="http://localhost:3000/{R:1}" />
                </rule>
            </rules>
        </rewrite>
    </system.webServer>
</configuration>
